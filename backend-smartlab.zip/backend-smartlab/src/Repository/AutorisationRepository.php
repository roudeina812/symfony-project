<?php

namespace App\Repository;

use Doctrine\ORM\EntityRepository;

class AutorisationRepository extends EntityRepository
{

}